<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class DashboardController extends Controller
{
    public function index(Request $request){
       
        $user = DB::table('user')->where(['user_name'=>$request->user_name,'role_type'=>$request->role_type,'token'=>$request->token])->count();
        if($user == 1){
            
           $arr = array();
           $day1 = date('Y-m-d', strtotime('-1 day'));
           $day7 = date('Y-m-d', strtotime('-7 day'));
           $day8 = date('Y-m-d', strtotime('-8 day'));
           $day9 = "1970-01-01";
           
            $column = ($request->role_type =='DST') ? 'r_employee':'l_employee';
            $headcenter = DB::table('headcenter')->where(['id'=>$request->centerid])->get()->toArray();
           
            $query = DB::table('lead_create')->where([$column=>$request->centerid]);

            $total_Sale_nt = $query->where(['ctype'=>''])->count();
            $total_Walkin = $query->where(['source'=>'Walkin'])->count();
            $total_Self = $query->where(['source'=>'Self'])->count();

            $total_Micro_Site = $query->where(['source'=>'Micro_Site'])->count();
            $totalfollowup = $query->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Dead'])->whereBetween('fDate',[date('Y-m-d'),date('Y-m-d')])->count();
           
            $totalfollowup7 = $query->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Dead'])->whereBetween('fDate',[$day7,$day1])->count();
            $totalfollowup8 = $query->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Dead'])->whereBetween('fDate',[$day9,$day8])->count();

            $arr['total_Sale_nt']    = $total_Sale_nt;
            $arr['total_Walkin']     = $total_Walkin;
            $arr['total_Self']       = $total_Self;
            $arr['total_Micro_Site'] = $total_Micro_Site;
            $arr['totalfollowup']    = $totalfollowup;
            $arr['totalfollowup7']   = $totalfollowup7;
            $arr['totalfollowup8']   = $totalfollowup8;
            $arr['headcenter']   = json_decode(json_encode($headcenter), true);


           return response(['status'=>200,'msg'=>['Login Success'],'data'=>$arr]);
            
        }
        else{
            return response(['status'=>404,'msg'=>['User not login']]);
        }
                

    }
}
