<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use DB;

class ApiAuthController extends Controller
{
    public function login (Request $request) {

        $validator = Validator::make($request->all(), [
            'user_name' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()){
             return response(['status'=>404,'msg'=>$validator->errors()->all()]);
        }

        #$user = User::where(['user_name'=>$request->user_name,'status'=>'a'])->get()->toArray();
        $user = User::where(['user_name'=>$request->user_name,'status'=>'a'])->whereIn('role_type',['DST','CPSM','Presales'])->get(['user_name','name','role_type','token','password','centerid'])->toArray();
        
        if ($user)
        {
            if ($user[0]['password'] == md5($request->password)){
                $token = Str::random(20);
                User::where(['user_name'=>$request->user_name,'status'=>'a'])->update(['token'=>$token]);
                unset($user[0]['password']);
                $user[0]['token'] = $token;
                return response(['status'=>200,'msg'=>['Login Success'],'data'=>$user]);
            } 
            else{
                return response(['status'=>404,'msg'=>['Password mismatch']]);
            }
        } 
        
        else
        {
            return response(['status'=>404,'msg'=>['User does not exist']]);
        }

    }

    public function logout (Request $request) {
        
        $user = User::where(['user_name'=>$request->user_name])->count(); 
        if ($user) {

            User::where(['user_name'=>$request->user_name,'status'=>'a'])->update(['token'=>'']);
            return response(['status'=>200,'msg'=>['You have been successfully logged out!']]);
        }
        else{
            return response(['status'=>404,'msg'=>['Something Error']]);
        }
        
    }

    
}
