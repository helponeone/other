$total_Sale_nt = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('ltype', '=', ' ')->orWhereNull('ltype')->where('display_status', '!=', 'N')->count();
            
            $totalfollowup = $query1->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Lost'])->whereBetween('fDate',[date('Y-m-d'),date('Y-m-d')])->count();
           
            $total_follw_Prospect_today = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('ltype', '!=', ' ')->where('display_status', '!=', 'N')->where(['ltype'=>'Site Visit Schedule'])->whereBetween('fDate',[date('Y-m-d'),date('Y-m-d')])->count();
        
            $totalfollowup7 =  DB::table('lead_create_multi')->where([$column=>$request->centerid])->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Lost'])->where('display_status', '!=', 'N')->where('ctype', '!=', 'Lost')->whereBetween('fDate',[$day7,$day1])->count();

            $totalfollowup8 = DB::table('lead_create_multi')->where([$column=>$request->centerid])->whereNotIn('ltype',['incoming','outgoing','new','cp','New','incomming','Conversation','Micro_Site','Lost'])->where('display_status', '!=', 'N')->where('ctype', '!=', 'Lost')->whereBetween('fDate',[$day9,$day8])->count();
            
            $total_visit = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('display_status', '!=', 'N')->where(['ltype'=>'Site Visits - Done'])->count();

            $total_Sale = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('display_status', '!=', 'N')->where(['ctype'=>'Sale'])->count();
            
            $total_Hot = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('display_status', '!=', 'N')->where(['ctype'=>'Hot'])->count();

            $total_Warm = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('display_status', '!=', 'N')->where(['ctype'=>'Warm'])->count();

            $total_Cold = DB::table('lead_create_multi')->where([$column=>$request->centerid])->where('display_status', '!=', 'N')->where(['ctype'=>'Cold'])->count();


            DB::select("select * from user where id='.$row_cust['w3techerp_an'].'");

           $sir =  DB::select( $sql="insert into lead_create (`l_pjln`,`r_employee`,`l_employee`,`izone`, `iregion`,`idivision`, `icenter`, `ibpid`,`l_prodt`,`l_bid`,`l_code`,`l_fname`,`l_lname`,`l_jtitle`,`l_email`,`l_pno`,`l_company`,`l_tfd`,`l_itos`,`l_rs`,`l_rsl`,`l_hqc`,`l_lhs`,`l_hc`,`l_ld`,`l_pcfn`,`l_pcln`,`l_pce`,`l_pcn`,`l_pcn1`,`l_pcn2`,`l_pcn3`,`l_pc`,`Property`,`adv`,`loca`,`pref`,`prof`,`eadd`,dtime,`smid`,`smmobile`,`source`,`vendor`,`lead_upload_date`,`lead_create_date`,`lead_update_date`,`lead_all_date`,`allocation_id`,`v_userid`,`v_username`,`v_date`,`status3`,`first_comment_date`,`last_comment_date`,`l_mobile`,`l_mobile1`,`l_mobile2`,`lead_allo_date`,`lead_allo_time`,`mul_proid`,`mul_proname`,`mul_procode`,`pre_mul_proid`,`pre_mul_proname`,`pre_mul_procode`,`purpose`)VALUES('$l_pjln','$centerid_dst','$centerid','$izone', '$iregion', '$idivision', '$icenter', '','$l_prodt','$l_bid','$l_code','$l_fname','$l_lname', '$l_jtitle','$l_email', '$l_pno','$l_company','$l_tfd','$l_itos','$l_rs','$l_rsl','$l_hqc','$l_lhs','$l_hc','$l_ld','$l_pcfn','$l_pcln','$l_pce','$l_pcn','$l_pcn1','$l_pcn2','$l_pcn3','$l_pc','$Property','$adv','$loca','$pref','$prof','$eadd',NOW(),'$centerid','$ihand','$source','$vendor','$date12','$date12','$date12','$date12','$user_id1','$user_table_id','$user_table_name','$v_date','$ibpid','$date12','$date12','$l_mobile','$l_mobile1','$l_mobile2','$redate','$retime','$row_proid_proid','$l_prodt','$mul_procode','$row_proid_proid','$l_prodt','$mul_procode','$new_purpse')";

            $arr = ['name'=>'Ki'];
            DB::table('user')->insert($arr);
 
);